from pyrogram import Client, filters
from pyrogram.types import Message
from datetime import datetime

bot_token = "7348168601:AAGE_g_zSjFsEGHNCZNKkUpj9g4aiJ-eDuU"
api_id = 12345
api_hash = "0123456789abcdef0123456789abcdef"

app = Client("bot_session", api_id=api_id, api_hash=api_hash, bot_token=bot_token)

active_chats = {}

def get_key(msg: Message):
    return (msg.chat.id, msg.message_thread_id or 0)

@app.on_message(filters.command("on") & filters.chat_type.groups)
def activate_bot(client, message: Message):
    key = get_key(message)
    active_chats[key] = datetime.utcnow()
    message.reply("✅ Бот включён. Новые сообщения будут удаляться.")

@app.on_message(filters.command("off") & filters.chat_type.groups)
def deactivate_bot(client, message: Message):
    key = get_key(message)
    if key in active_chats:
        del active_chats[key]
        message.reply("⛔ Бот выключен.")
    else:
        message.reply("⚠️ Бот и так был выключен.")

@app.on_message(filters.chat_type.groups)
def delete_new_messages(client, message: Message):
    key = get_key(message)
    if key in active_chats:
        start_time = active_chats[key]
        if message.date > start_time:
            try:
                client.delete_messages(message.chat.id, message.id)
            except Exception as e:
                print(f"Ошибка при удалении: {e}")

print("🤖 Бот запущен и работает 24/7...")
app.run()
